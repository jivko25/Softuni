package Softuni.JavaOOP.Polymorphism.Vehicles;

public abstract class Vehicle {
	public abstract void refuel(double fueal);
	public abstract void drive(double distance);
	public abstract void print();
}
