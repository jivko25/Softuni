package Softuni.JavaOOP.WorkingWithAbstraction.CardRank;

public enum CardRanksEnum {
    ACE(),
    TWO(),
    THREE(),
    FOUR(),
    FIVE(),
    SIX(),
    SEVEN(),
    EIGHT(),
    NINE(),
    TEN(),
    JACK(),
    QUEEN(),
    KING()
}
