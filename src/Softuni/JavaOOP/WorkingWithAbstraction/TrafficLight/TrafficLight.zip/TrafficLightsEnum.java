package Softuni.JavaOOP.WorkingWithAbstraction.TrafficLight;

public enum TrafficLightsEnum {
	GREEN,
	YELLOW,
	RED;
}
