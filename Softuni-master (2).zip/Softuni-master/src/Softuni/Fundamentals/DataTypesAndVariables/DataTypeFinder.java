package Softuni.Fundamentals.DataTypesAndVariables;

public class DataTypeFinder {

}
